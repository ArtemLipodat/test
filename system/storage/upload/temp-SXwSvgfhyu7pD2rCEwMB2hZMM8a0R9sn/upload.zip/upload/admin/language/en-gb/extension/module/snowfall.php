<?php
// Heading
$_['heading_title']         = '<strong style="color:#41637d">DEV-OPENCART.COM —</strong> <b>Падающий снег на сайте</b> <a href="https://dev-opencart.com" target="_blank" title="Dev-opencart.com - Модули и шаблоны для Opencart"><img style="margin-left:15px;height:35px;margin-top:10px;margin-bottom:10px;" src="https://dev-opencart.com/logob.svg" alt="Dev-opencart.com - Модули и шаблоны для Opencart"/></a>';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified module!';
$_['text_edit']        = 'Edit Featured Module';
$_['entry_status'] = 'Status';
$_['entry_flakecount'] = 'Number of snowflakes per page';
$_['entry_flakecolor'] = 'Snowflake color';
$_['entry_flakeindex'] = 'CSS z-index of snowflakes';
$_['entry_minsize'] = 'Minimum size of a snowflake';
$_['entry_maxsize'] = 'Maximum size of a snowflake';
$_['entry_minspeed'] = 'Minimum snowflake speed';
$_['entry_maxspeed'] = 'Maximum speed for snowflakes to fall';
$_['entry_round'] = 'Round snowflakes are true, square snowflakes are false';
$_['entry_shadow'] = 'Snowflake shadow';
$_['entry_collection'] = 'The class or id of the element above which snowflakes will settle and accumulate';